fun main(){
    // Arreglo con las estaciones del año
    val estaciones = arrayOf("Primavera","Verano","Otoño", "Invierno")

    // Impresión con for each
    println("\nImpresión con for each\n")
    for(estacion in estaciones){
      println(estacion)
    }

    // Impresión con for y un rango
    println("\nImpresión con for\n")
    for(i in 0..3){
      println(estaciones[i])
    }

    // Impresión con while
    println("\nImpresión con while\n")
    var cont = 0
    while(cont < 4){
      println(estaciones[cont])
      cont += 1
    }
}