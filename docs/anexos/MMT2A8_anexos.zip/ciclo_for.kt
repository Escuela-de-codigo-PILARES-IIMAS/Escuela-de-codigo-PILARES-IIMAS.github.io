fun main(){
    // Recorriendo las horas de un día
    println("\nImprimiendo las horas de un día\n")
    for(i in 0..23)
      println("$i:00")
    
    // Números pares del 2 al 20
    println("\nNúmeros pares del 2 al 20\n")
    for(i in 2..20 step 2)
      println(i)
}