fun main(){
    val entero : Int = 0
    val entero2 : Int = -4
    val short : Short = 123
    val long : Long = 1234
    val float : Float = 0.5f
    val double : Double = 0.55
    val char : Char = 'c'
    val string : String = "true"
    val string2 : String = "t"
    val boolean : Boolean = false
}