fun main(){ 

    /* En esta sección escribe tu código */

    /* Declaraciones implicítas del tipo de una variable */
    val numero = 0
    inferirTipo(numero)

    
    /* Declaraciones explicítas del tipo de una variable */
    //val short : Short = 1234
    //inferirTipo(short)
   
}

/*
 * Esta función imprime el tipo al que pertenece el dato que se le pasa como parámetro.
 * 
 * No te preocupes si no entiendes por completo a que se refiere el enunciado anterior,
 * centremonos en su funcionamiento.
 * 
 * Cada que quieras saber el tipo de una variable debes hacer lo siguiente:
 * 
 * 1. Declara la variable
 * 2. En la siguiente línea,coloca la palabra inferirTipo()
 * 3. Coloca dentro del paréntesis de lo que recién escribiste el nombre de tu variable
 * 4. ¡Ejecuta tu programa!
 *  
 * */
 
fun inferirTipo(dato : Any){
    print("El dato $dato es de tipo: ")
    when(dato){
        is Byte -> println("Byte")
        is Short -> println("Short")
        is Int -> println("Int")
        is Long -> println("Long")
        is Float -> println("Float")
        is Double -> println("Double")
        is Char -> println("Char")
        is String -> println("String")
        is Boolean -> println("Boolean")
    }   
}